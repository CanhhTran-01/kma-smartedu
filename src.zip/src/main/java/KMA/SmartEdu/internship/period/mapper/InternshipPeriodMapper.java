package KMA.SmartEdu.internship.period.mapper;

import KMA.SmartEdu.internship.period.dto.InternshipPeriodRequest;
import KMA.SmartEdu.internship.period.dto.InternshipPeriodResponse;
import KMA.SmartEdu.internship.period.entity.InternshipPeriod;
import KMA.SmartEdu.internship.period.enums.PeriodStatus;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring", nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface InternshipPeriodMapper {

    InternshipPeriod toEntity(InternshipPeriodRequest request);

    // status không map trực tiếp từ field nào của entity - phải tính động theo ngày hiện tại,
    // nên ignore ở đây rồi set ở @AfterMapping bên dưới
    @Mapping(target = "status", ignore = true)
    InternshipPeriodResponse toResponse(InternshipPeriod internshipPeriod);

    void updateEntityFromRequest(InternshipPeriodRequest request, @MappingTarget InternshipPeriod internshipPeriod);

    @AfterMapping
    default void fillStatus(@MappingTarget InternshipPeriodResponse response, InternshipPeriod internshipPeriod) {
        response.setStatus(PeriodStatus.of(
                internshipPeriod.getStartDate(),
                internshipPeriod.getEndDate(),
                internshipPeriod.getRegistrationDeadline()));
    }
}
